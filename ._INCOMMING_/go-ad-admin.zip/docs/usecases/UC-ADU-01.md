# UC-ADU-01 Suche

- Eingabe: Query, Limit
- Ergebnis: Liste (pseudonymisiert wenn privacy=high)
- Timeout 2s → Fehlermeldung mit Retry-Hinweis
