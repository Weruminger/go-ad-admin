# Requirement: DHCP-KEA

- HTTPS-API mit Token
- Subnet/Reservation CRUD
- Timeouts (2s), Retry (3x, exp backoff)
- Audit aller Änderungen
