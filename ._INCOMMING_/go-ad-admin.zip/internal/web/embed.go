package web

import "embed"

//go:embed ../../web/templates/*
var templates embed.FS
